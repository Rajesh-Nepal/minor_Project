from django.urls import path
from django.urls import include
from . import views

app_name = 'covid19_and_pneumonia detection'

urlpatterns = [
    #path('', views.home, name='covid-home'),
    path('seedinfo/', views.seedinfo, name='seedinfo'),
    path('gallery/', views.gallery, name='gallery'),
    path('aboutus/', views.aboutus, name='aboutus'),
    path('',views.index, name='index')
]