from django.apps import AppConfig


class CovidprojectConfig(AppConfig):
    name = 'covidproject'
